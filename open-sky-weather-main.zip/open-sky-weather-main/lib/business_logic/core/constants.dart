String appName = "Open Sky Weather";
String sku = "osw";
String version = "1.0";
