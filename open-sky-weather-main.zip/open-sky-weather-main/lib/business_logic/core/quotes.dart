const dayQuotes = [
  "With the new day comes new strength and new thoughts",
  "Ever tried. Ever failed. No matter. Try Again. Fail again. Fail better",
  "Either you run the day or the day runs you",
  "Every day brings new choices",
  "Life lived for tomorrow will always be just a day away from being realized",
  "A day without laughter is a day wasted",
  "The sky is filled with stars, invisible by day",
  "Every day, in every way, I'm getting better and better",
  "I will prepare and some day my chance will come",
  "Another shiny new day"
];

const nightQuotes = [
  "There's no night without stars",
  "Think in the morning. Act in the noon. Eat in the evening. Sleep in the night",
  "Good Night! Sweet Dreams!",
  "I often think that the night is more alive and more richly colored than the day",
  "Look at the stars, dream big, work hard",
  "Take a deep breath. Gather all the positivity for tomorrow"
];
