import 'package:sqflite/sqflite.dart';

class MySavedItemHelper {
  Database? db;
}
