import 'package:get_storage/get_storage.dart';

void eraseAll() {
  GetStorage().erase();
}
