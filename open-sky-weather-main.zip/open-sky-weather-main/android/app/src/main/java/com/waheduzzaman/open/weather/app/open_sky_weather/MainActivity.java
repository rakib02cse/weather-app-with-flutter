package com.waheduzzaman.open.weather.app.open_sky_weather;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
