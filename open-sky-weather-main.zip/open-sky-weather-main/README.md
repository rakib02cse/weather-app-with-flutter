# open_sky_weather

A Flutter project that shows your current weather.

## Getting Started

This project is a part of the ongoing class conducted for Aflion.
This project may not run out of box as it needs to be configured a bit
(firebase, weather api key). 

However, you can explore the packaging, structures and reuse pieces of this project if you want.
----------